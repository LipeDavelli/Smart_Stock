﻿using prjDil;
using prjDto;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace prjDal
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Access Layer
    /// Public
    /// Properties:
    /// Public
    /// Methods:        List<DtoCliente> SelectCliente()
    ///                 DtoCliente SelectCliente(int IdCliente)
    ///                 void InsertCliente(DtoCliente cliente)
    ///                 public void EditCliente(DtoCliente cliente)
    ///                 void DeleteCliente(int IdCliente)
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class Dal
    {
        #region PROPERTIES

        private Dil objDil = null;
        #endregion PROPERTIES

        #region CONSTRUCTORS
        public Dal()
        {
            objDil = new Dil();
        }
        #endregion CONSTRUCTORS

        #region METHODS
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// NESTA SEÇÃO ESTAO OS MÉTODOS QUE IMPLEMENTAM AS FUNÇÕES DE ACESSO À CADA ENTIDADE NO DATABASE ///
        /////////////////////////////////////////////////////////////////////////////////////////////////////


        #region PECA

        public List<DtoPeca> SelectPeca()
        {
            try
            {
                DataTable dtPecas = objDil.ExecuteStoredProcedureQuery("sp_select_peca");

                DtoPeca peca = null;

                List<DtoPeca> lstPecas = new List<DtoPeca>();

                foreach (DataRow row in dtPecas.Rows)
                {
                    peca = new DtoPeca(row);
                    lstPecas.Add(peca);
                    peca = null;
                }

                return lstPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoPeca> SelectPecaPesquisa(string pesquisa)
        {
            try
            {
                objDil.AddParameter("@p_search", pesquisa);
                DataTable dtPecas = objDil.ExecuteStoredProcedureQuery("sp_select_peca");

                DtoPeca peca = null;

                List<DtoPeca> lstPecas = new List<DtoPeca>();

                foreach (DataRow row in dtPecas.Rows)
                {
                    peca = new DtoPeca(row);
                    lstPecas.Add(peca);
                    peca = null;
                }

                return lstPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoPeca SelectPeca(int IdPeca)
        {
            try
            {
                objDil.AddParameter("@p_cod_peca", IdPeca);

                DataTable dtPecas = objDil.ExecuteStoredProcedureQuery("sp_select_peca_by_cod");

                DtoPeca objPeca = null;

                if (dtPecas.Rows.Count > 0)
                    objPeca = new DtoPeca(dtPecas.Rows[0]);

                return objPeca;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertPeca(DtoPeca peca)
        {
            try
            {
                objDil.AddParameter("@p_nome_peca", peca.NomePeca);
                objDil.AddParameter("@p_quantidade", peca.QuantidadeEstoque);
                objDil.AddParameter("@p_modelo", peca.Modelo);

                peca.IdPeca  = (int)objDil.ExecuteAFieldQuery(CommandType.StoredProcedure, "sp_insert_peca");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

            public int InsertPecaMax(DtoPeca peca)
        {
            try
            {
                objDil.AddParameter("@p_nome_peca", peca.NomePeca);
                objDil.AddParameter("@p_quantidade", peca.QuantidadeEstoque);
                objDil.AddParameter("@p_modelo", peca.Modelo);

                return (int)objDil.ExecuteCommandScalar("sp_insert_peca_max");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditPeca(DtoPeca peca)
        {
            try
            {
                objDil.AddParameter("@p_cod_peca", peca.IdPeca);
                objDil.AddParameter("@p_nome_peca", peca.NomePeca);
                objDil.AddParameter("@p_quantidade", peca.QuantidadeEstoque);
                objDil.AddParameter("@p_modelo", peca.Modelo);

                objDil.ExecuteStoredProcedureNonQuery("sp_update_peca");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeletePeca(int IdPeca)
        {
            try
            {
                objDil.AddParameter("@p_cod_peca", IdPeca);

                objDil.ExecuteStoredProcedureNonQuery("sp_delete_peca");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion PECA

        #region KIT
        public List<DtoKit> SelectKit()
        {
            try
            {
                DataTable dtKits = objDil.ExecuteStoredProcedureQuery("sp_select_kit");

                DtoKit kit = null;

                List<DtoKit> lstKits = new List<DtoKit>();

                foreach (DataRow row in dtKits.Rows)
                {
                    kit = new DtoKit(row);
                    lstKits.Add(kit);
                    kit = null;
                }

                return lstKits;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoKit SelectKit(int IdKit)
        {
            try
            {
                objDil.AddParameter("@p_id_kit", IdKit);

                DataTable dtKits = objDil.ExecuteStoredProcedureQuery("sp_select_kit_by_cod");

                DtoKit objKit = null;

                if (dtKits.Rows.Count > 0)
                    objKit = new DtoKit(dtKits.Rows[0]);

                return objKit;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertKit(DtoKit kit)
        {
            try
            {
                objDil.AddParameter("@p_nome_kit", kit.NomeKit);
                objDil.AddParameter("@p_descricao", kit.Descricao);

                kit.IdKit = objDil.ExecuteStoredProcedureNonQuery("sp_insert_kit");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditKit(DtoKit kit)
        {
            try
            {
                objDil.AddParameter("@p_cod_kit", kit.IdKit);
                objDil.AddParameter("@p_nome_kit", kit.NomeKit);
                objDil.AddParameter("@p_descricao", kit.Descricao);

                objDil.ExecuteStoredProcedureNonQuery("sp_update_kit");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteKit(int IdKit)
        {
            try
            {
                objDil.AddParameter("@p_cod_kit", IdKit);

                objDil.ExecuteStoredProcedureNonQuery("sp_delete_kit");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion KIT

        #region ESTOQUE
        public List<DtoEstoque> SelectEstoque()
        {
            try
            {
                DataTable dtEstoques = objDil.ExecuteStoredProcedureQuery("sp_select_estoque");

                DtoEstoque estoque = null;

                List<DtoEstoque> lstEstoques = new List<DtoEstoque>();

                foreach (DataRow row in dtEstoques.Rows)
                {
                    estoque = new DtoEstoque(row);
                    lstEstoques.Add(estoque);
                    estoque = null;
                }

                return lstEstoques;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEstoque SelectEstoque(int IdEstoque)
        {
            try
            {
                objDil.AddParameter("@p_cod_estoque", IdEstoque);

                DataTable dtEstoques = objDil.ExecuteStoredProcedureQuery("sp_select_estoque_by_cod");

                DtoEstoque objEstoque = null;

                if (dtEstoques.Rows.Count > 0)
                    objEstoque = new DtoEstoque(dtEstoques.Rows[0]);

                return objEstoque;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEstoque(DtoEstoque estoque)
        {
            try
            {
                objDil.AddParameter("@p_nome_modelo", estoque.NomeModelo);
                objDil.AddParameter("@p_quantidade", estoque.Quantidade);

                objDil.ExecuteStoredProcedureNonQuery("sp_insert_estoque");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditEstoque(DtoEstoque estoque)
        {
            try
            {
                objDil.AddParameter("@p_cod_estoque", estoque.IdEstoque);
                objDil.AddParameter("@p_nome_modelo", estoque.NomeModelo);
                objDil.AddParameter("@p_quantidade", estoque.Quantidade);

                objDil.ExecuteStoredProcedureNonQuery("sp_update_estoque");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEstoque(int IdEstoque)
        {
            try
            {
                objDil.AddParameter("@p_cod_estoque", IdEstoque);

                objDil.ExecuteStoredProcedureNonQuery("sp_delete_estoque");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion ESTOQUE

        #region ENTRADA E SAIDA
        public List<DtoEntradaSaida> SelectEntradaSaida(string pesquisa)
        {
            try
            {
                objDil.AddParameter("@p_search", pesquisa);

                DataTable dtEntradaSaidas = objDil.ExecuteStoredProcedureQuery("sp_select_entrada_saida");

                DtoEntradaSaida entradasaida = null;

                List<DtoEntradaSaida> lstEntradaSaidas = new List<DtoEntradaSaida>();

                foreach (DataRow row in dtEntradaSaidas.Rows)
                {
                    entradasaida = new DtoEntradaSaida(row);
                    lstEntradaSaidas.Add(entradasaida);
                    entradasaida = null;
                }

                return lstEntradaSaidas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoEntradaSaida> SelectEntradaSaidaPesquisa(string pesquisa)
        {
            try
            {
                objDil.AddParameter("@p_search", pesquisa);

                DataTable dtEntradaSaidas = objDil.ExecuteStoredProcedureQuery("sp_select_entrada_saida");

                DtoEntradaSaida entradasaida = null;

                List<DtoEntradaSaida> lstEntradaSaidas = new List<DtoEntradaSaida>();

                foreach (DataRow row in dtEntradaSaidas.Rows)
                {
                    entradasaida = new DtoEntradaSaida(row);
                    lstEntradaSaidas.Add(entradasaida);
                    entradasaida = null;
                }

                return lstEntradaSaidas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEntradaSaida SelectEntradaSaida(int IdEntradaSaida)
        {
            try
            {
                objDil.AddParameter("@p_cod_entrada_saida", IdEntradaSaida);

                DataTable dtEntradaSaidas = objDil.ExecuteStoredProcedureQuery("sp_select_entrada_saida_by_cod");

                DtoEntradaSaida objEntradaSaida = null;

                if (dtEntradaSaidas.Rows.Count > 0)
                    objEntradaSaida = new DtoEntradaSaida(dtEntradaSaidas.Rows[0]);

                return objEntradaSaida;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaida(DtoEntradaSaida entradasaida)
        {
            try
            {
                objDil.ClearParameterCollection();

                objDil.AddParameter("@p_numero_ordem", entradasaida.NumeroOrdem);
                objDil.AddParameter("@p_quantidade", entradasaida.Quantidade);
                objDil.AddParameter("@p_cod_peca", entradasaida.Peca.IdPeca);
                objDil.AddParameter("@p_cod_kit", entradasaida.Kit.IdKit);

                entradasaida.IdEntradaSaida = objDil.ExecuteStoredProcedureNonQuery("sp_insert_entrada_saida");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaidaMax(DtoEntradaSaida entradasaida)
        {
            try
            {
                objDil.ClearParameterCollection();

                objDil.AddParameter("@p_numero_ordem", entradasaida.NumeroOrdem);
                objDil.AddParameter("@p_quantidade", entradasaida.Quantidade);
                objDil.AddParameter("@p_cod_peca", entradasaida.Peca.IdPeca);
                objDil.AddParameter("@p_cod_kit", entradasaida.Kit.IdKit);

                entradasaida.IdEntradaSaida = objDil.ExecuteStoredProcedureNonQuery("sp_insert_entrada_saida");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaidaKit(int IdKit, string NumeroOrdem)
        {
            try
            {
                objDil.ClearParameterCollection();
                objDil.AddParameter("@p_numero_ordem", NumeroOrdem);
                objDil.AddParameter("@p_cod_kit", IdKit);

                objDil.ExecuteStoredProcedureNonQuery("sp_insert_entrada_saida_kit");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditEntradaSaida(DtoEntradaSaida entradasaida)
        {
            try
            {
                objDil.AddParameter("@p_cod_entrada_saida", entradasaida.IdEntradaSaida);
                objDil.AddParameter("@p_nome", entradasaida.NumeroOrdem);
                objDil.AddParameter("@p_quantidade", entradasaida.Quantidade);

                objDil.ExecuteStoredProcedureNonQuery("sp_update_entrada_saida");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEntradaSaida(int IdEntradaSaida)
        {
            try
            {
                objDil.AddParameter("@p_cod_entrada_saida", IdEntradaSaida);

                objDil.ExecuteStoredProcedureNonQuery("sp_delete_entrada_saida");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoEntradaSaida> SelectData(DateTime Data)
        {
            try
            {
                objDil.ClearParameterCollection();

                objDil.AddParameter("@p_data", Data);

                DataTable dtEntradasSaidas = objDil.ExecuteStoredProcedureQuery("sp_entrada_saida_data");

                DtoEntradaSaida entradasaida = null;

                List<DtoEntradaSaida> lstEntradaSaidas = new List<DtoEntradaSaida>();

                foreach (DataRow row in dtEntradasSaidas.Rows)
                {
                    entradasaida = new DtoEntradaSaida(row);
                    lstEntradaSaidas.Add(entradasaida);
                    entradasaida = null;
                }

                return lstEntradaSaidas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion ENTRADA E SAIDA

        #region KIT PECA
        public List<DtoKitPeca> SelectKitPeca()
        {
            try
            {

                DataTable dtKitPecas = objDil.ExecuteStoredProcedureQuery("sp_select_kit_peca");

                DtoKitPeca kitpeca = null;

                List<DtoKitPeca> lstKitPecas = new List<DtoKitPeca>();

                foreach (DataRow row in dtKitPecas.Rows)
                {
                    kitpeca = new DtoKitPeca(row);
                    lstKitPecas.Add(kitpeca);
                    kitpeca = null;
                }

                return lstKitPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoKitPeca> SelectKitPeca(int IdKitPeca)
        {
            try
            {
                objDil.AddParameter("@p_cod_kit_peca", IdKitPeca);

                DataTable dtKitPecas = objDil.ExecuteStoredProcedureQuery("sp_select_kit_peca_by_cod");

                List<DtoKitPeca> objKitPeca = new List<DtoKitPeca>();

                foreach (DataRow linha in dtKitPecas.Rows)
                {
                    objKitPeca.Add(new DtoKitPeca(linha));
                }

                return objKitPeca;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertKitPeca(DtoKitPeca kitpeca)
        {
            try
            {
                objDil.AddParameter("@p_cod_peca", kitpeca.Peca.IdPeca);
                objDil.AddParameter("@p_cod_kit", kitpeca.Kit.IdKit);
                objDil.AddParameter("@p_quantidade", kitpeca.Quantidade);

                kitpeca.Peca.IdPeca = objDil.ExecuteStoredProcedureNonQuery("sp_insert_kit_peca");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditKitPeca(DtoKitPeca kitpeca)
        {
            try
            {
                objDil.AddParameter("@p_cod_kit_peca", kitpeca.Kit.pecas);
                objDil.AddParameter("@p_cod_peca", kitpeca.Peca.IdPeca);
                objDil.AddParameter("@p_cod_kit", kitpeca.Kit.IdKit);
                objDil.AddParameter("@p_quantidade", kitpeca.Quantidade);

                objDil.ExecuteStoredProcedureNonQuery("sp_update_kit_peca");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteKitPeca(int IdKitPeca)
        {
            try
            {
                objDil.AddParameter("@p_id_kit_peca", IdKitPeca);

                objDil.ExecuteStoredProcedureNonQuery("sp_delete_kit_peca");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion KIT PECA

        #endregion METHODS
    }
}
