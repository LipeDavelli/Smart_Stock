﻿using System;
using System.Configuration;
using System.Data;

namespace prjDto
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Transference Object - Estado
    /// Public
    /// Properties:     int IdEstado
    ///                 string Nome
    ///                 string Sigla
    /// Public
    /// Methods:        
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class DtoPeca
    {
        #region PROPERTIES
        
        public int IdPeca { get; set; }
        public string NomePeca { get; set; }
        public int QuantidadeEstoque { get; set; }
        public string Modelo { get; set; }
        #endregion PROPERTIES

        public override string ToString()
        {
            return string.Format("{0} - {1}", NomePeca, Modelo);
        }

        #region CONSTRUCTORS

        public DtoPeca()
        {

        }

        public DtoPeca(DataRow row)
        {
            try
            {
                this.IdPeca = int.Parse(row["cod_peca"].ToString());
                this.NomePeca = row["nome_peca"].ToString();
                this.QuantidadeEstoque = int.Parse(row["quantidade"].ToString());
                this.Modelo = row["modelo"].ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoPeca(string p_NomePeca
                     , int p_QuantidadeEstoque
                     , string p_Modelo
                     , int p_IdPeca = 0)
        {
            try
            {
                this.IdPeca = p_IdPeca;
                this.NomePeca = p_NomePeca;
                this.QuantidadeEstoque = p_QuantidadeEstoque;
                this.Modelo = p_Modelo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion CONSTRUCTORS
    }
}
