﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;

namespace prjDto
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Transference Object - Cliente
    /// Public
    /// Properties:     int IdCliente
    ///                 string Nome
    ///                 string SegundoNome
    ///                 string Sobrenome
    ///                 DateTime DataNascimento
    ///                 bool Genero
    ///                 int IdEstado
    ///                 string SiglaEstado
    /// Public
    /// Methods:        
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class DtoEstoque
    {
        #region PROPERTIES
        
        public int IdEstoque { get; set; }
        public int IdPeca { get; set; }
        public string NomeModelo { get; set; }
        public int Quantidade { get; set; }
        #endregion PROPERTIES

        #region CONSTRUCTORS
        public DtoEstoque(DataRow row)
        {
            try
            {
                this.IdEstoque = int.Parse(row["id_estoque"].ToString());
                this.IdPeca = int.Parse(row["id_peca"].ToString());
                this.NomeModelo = row["nome_modelo"].ToString();
                this.Quantidade = int.Parse(row["quantidade"].ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEstoque(int p_IdEstoque
                     , int p_IdPeca
                     , string p_NomeModelo
                     , int p_Quantidade)
        {
            try
            {
                this.IdEstoque = p_IdEstoque;
                this.IdPeca = p_IdPeca;
                this.NomeModelo = p_NomeModelo;
                this.Quantidade = p_Quantidade;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion CONSTRUCTORS
    }
}
