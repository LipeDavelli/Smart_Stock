﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;

namespace prjDto
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Transference Object - Cliente
    /// Public
    /// Properties:     int IdCliente
    ///                 string Nome
    ///                 string SegundoNome
    ///                 string Sobrenome
    ///                 DateTime DataNascimento
    ///                 bool Genero
    ///                 int IdEstado
    ///                 string SiglaEstado
    /// Public
    /// Methods:        
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class DtoKitPeca
    {
        #region PROPERTIES

        public DtoPeca Peca { get; set; }
        public DtoKit Kit { get; set; }
        public int Quantidade { get; set; }

        #endregion PROPERTIES

        #region CONSTRUCTORS
        public DtoKitPeca(DataRow row)
        {
            try
            {
                this.Peca = new DtoPeca()
                {
                    IdPeca = int.Parse(row["cod_peca"].ToString()),
                    NomePeca = row["nome_peca"].ToString(),
                    QuantidadeEstoque = int.Parse(row["quantidade_estoque"].ToString())
                };
                this.Kit = new DtoKit()
                {
                    IdKit = int.Parse(row["cod_kit"].ToString()),
                    NomeKit = row["nome_kit"].ToString(),
                    Descricao = row["descricao"].ToString()
                };
                this.Quantidade = int.Parse(row["quantidade_kit"].ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoKitPeca(int p_IdPeca
                     , string p_NomePeca
                     , int p_QuantidadeEstoque
                     , int p_IdKit
                     , string p_NomeKit
                     , string p_Descricao
                     , int p_Quantidade)
        {
            try
            {
                this.Peca.IdPeca = p_IdPeca;
                this.Peca.NomePeca = p_NomePeca;
                this.Peca.QuantidadeEstoque = p_QuantidadeEstoque;
                this.Kit.IdKit = p_IdKit;
                this.Kit.NomeKit = p_NomeKit;
                this.Kit.Descricao = p_Descricao;
                this.Quantidade = p_Quantidade;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion CONSTRUCTORS
    }
}
