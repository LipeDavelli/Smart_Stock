﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;

namespace prjDto
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Transference Object - Cliente
    /// Public
    /// Properties:     int IdCliente
    ///                 string Nome
    ///                 string SegundoNome
    ///                 string Sobrenome
    ///                 DateTime DataNascimento
    ///                 bool Genero
    ///                 int IdEstado
    ///                 string SiglaEstado
    /// Public
    /// Methods:        
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    ///
    ///---    
    /// =======================================================================
    /// </summary>
    public class DtoEntradaSaida
    {
        #region PROPERTIES
        
        public int? IdEntradaSaida { get; set; }
        public string NumeroOrdem { get; set; }
        public DtoPeca Peca { get; set; }
        public DtoKit Kit { get; set; }
        public int Quantidade { get; set; }
        public DateTime Data { get; set; }

        #endregion PROPERTIES

        #region CONSTRUCTORS
        public DtoEntradaSaida(DataRow row)
        {
            try
            {
                this.IdEntradaSaida = int.Parse(row["cod_entrada_saida"].ToString());
                this.NumeroOrdem = row["numero_ordem"] != DBNull.Value ? row["numero_ordem"].ToString() : "Entrada".ToString();
                this.Peca = new DtoPeca() { IdPeca = int.Parse(row["cod_peca"].ToString()), NomePeca = row["nome_peca"].ToString(), Modelo = row["modelo"].ToString() };
                this.Kit = new DtoKit() {
                    IdKit = row["cod_kit"] != DBNull.Value ? int.Parse(row["cod_kit"].ToString()) : 0,
                    NomeKit = row["nome_kit"] != DBNull.Value ? row["nome_kit"].ToString() : "Entrada"
                //    Descricao = row["descricao"] != DBNull.Value ? row["descricao"].ToString(): ""
                };
                this.Quantidade = int.Parse(row["quantidade_peca"].ToString());
                this.Data = DateTime.Parse(row["data"].ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //
        public DtoEntradaSaida(DtoPeca peca, DtoKit kit)
        {
            try
            {
                Peca = peca;
                Kit = kit;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEntradaSaida()
        {
        }
        #endregion CONSTRUCTORS
    }
}
