﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;

namespace prjDto
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Database Transference Object - Estado
    /// Public
    /// Properties:     int IdEstado
    ///                 string Nome
    ///                 string Sigla
    /// Public
    /// Methods:        
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class DtoKit
    {
        #region PROPERTIES

        public int IdKit { get; set; }
        public string NomeKit { get; set; }
        public string Descricao { get; set; }

        public List<DtoKitPeca> pecas {get ;set ;}

        #endregion PROPERTIES

        #region CONSTRUCTORS

        public override string ToString()
        {
            return NomeKit;
        }

        public DtoKit(DataRow row)
        {
            try
            {
                this.IdKit = int.Parse(row["cod_kit"].ToString());
                this.NomeKit = row["nome_kit"].ToString();
                this.Descricao = row["descricao"].ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoKit(string p_NomeKit
                     , string p_Descricao
                     , int p_IdKit = 0)
        {
            try
            {
                this.NomeKit = p_NomeKit;
                this.Descricao = p_Descricao;
                this.IdKit = p_IdKit;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoKit()
        {
        }
        #endregion CONSTRUCTORS
    }
}
