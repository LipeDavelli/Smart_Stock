﻿using prjDal;
using prjDto;
using System;
using System.Collections.Generic;
using System.Configuration;


namespace prjBll
{
    /// <summary>
    /// =======================================================================
    /// Author:         Trevisan, Gilmar
    /// Create date:    27/05/2016
    /// Description:    Business Logic Layer
    /// Public
    /// Properties:     
    /// Public
    /// Methods:        List<DtoCliente> SelectCliente()
    ///                 DtoCliente SelectCliente(int p_IdCliente)
    ///                 void EditCliente(DtoCliente p_Cliente)
    ///                 void InsertCliente(DtoCliente p_Cliente)
    ///                 void DeleteCliente(int p_IdCliente)
    /// Dependencies:   System.Configuraton
    ///                 log4net
    /// Error control:  Exceções são elevadas ao método chamador
    ///                 Mensagens de erro são registradas no arquivo de log definido
    ///                 na seção log4net do arquivo Web.config
    /// =======================================================================
    /// </summary>
    public class Bll
    {
        #region PROPERTIE

        // Referência da classe DAL
        private Dal objDal = null;

        #endregion PROPERTIE

        #region CONSTRUCTORS
        public Bll()
        {
            this.objDal = new Dal();
        }
        #endregion CONSTRUCTORS

        #region METHODS

        #region PECA

        public List<DtoPeca> SelectPeca()
        {
            try
            {
                List<DtoPeca> lstPecas = null;

                lstPecas = objDal.SelectPeca();

                return lstPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public List<DtoPeca> SelectPecaPesquisa(string pesquisa)
        {
            try
            {
                List<DtoPeca> lstPecas = null;
                
                lstPecas = objDal.SelectPecaPesquisa(pesquisa);

                return lstPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoPeca SelectPeca(int p_IdPeca)
        {
            try
            {
                DtoPeca objPeca = objDal.SelectPeca(p_IdPeca);

                return objPeca;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditPeca(DtoPeca p_Peca)
        {
            try
            {
                CheckFieldsPeca(p_Peca);

                // Remove espaços à esquerda e à direita
                p_Peca.NomePeca = p_Peca.NomePeca.Trim();

                objDal.EditPeca(p_Peca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertPeca(DtoPeca p_Peca)
        {
            try
            {
                CheckFieldsPeca(p_Peca);

                // Remove espaços à esquerda e à direita
                p_Peca.NomePeca = p_Peca.NomePeca.Trim();

                objDal.InsertPeca(p_Peca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int InsertPecaMax(DtoPeca p_Peca)
        {
            try
            {
                CheckFieldsPeca(p_Peca);

                // Remove espaços à esquerda e à direita
                p_Peca.NomePeca = p_Peca.NomePeca.Trim();

                return objDal.InsertPecaMax(p_Peca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void DeletePeca(int p_IdPeca)
        {
            try
            {
                objDal.DeletePeca(p_IdPeca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CheckFieldsPeca(DtoPeca p_Peca)
        {
            // Validações de campo são obrigatórias na camada DLL
            // mesmo que já tenham sido feitas na camada PL
            if (p_Peca.NomePeca.Trim() == String.Empty)
            {
                Exception ex = new Exception("O campo Nome é obrigatório");

                throw ex;
            }
        }
        #endregion PECA

        #region KIT

        public List<DtoKit> SelectKit()
        {
            try
            {
                List<DtoKit> lstKits = null;

                lstKits = objDal.SelectKit();

                return lstKits;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoKit SelectKit(int p_IdKit)
        {
            try
            {
                DtoKit objKit = objDal.SelectKit(p_IdKit);

                return objKit;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditKit(DtoKit p_Kit)
        {
            try
            {
                CheckFieldsKit(p_Kit);

                // Remove espaços à esquerda e à direita
                p_Kit.NomeKit = p_Kit.NomeKit.Trim();
                p_Kit.Descricao = p_Kit.Descricao.Trim();

                objDal.EditKit(p_Kit);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertKit(DtoKit p_Kit)
        {
            try
            {
                CheckFieldsKit(p_Kit);

                // Remove espaços à esquerda e à direita
                p_Kit.NomeKit = p_Kit.NomeKit.Trim();
                p_Kit.Descricao = p_Kit.Descricao.Trim();

                objDal.InsertKit(p_Kit);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteKit(int p_IdKit)
        {
            try
            {
                objDal.DeleteKit(p_IdKit);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CheckFieldsKit(DtoKit p_Kit)
        {
            // Validações de campo são obrigatórias na camada DLL
            // mesmo que já tenham sido feitas na camada PL
            if (p_Kit.NomeKit.Trim() == String.Empty)
            {
                Exception ex = new Exception("O campo Nome é obrigatório");

                throw ex;
            }

            if (p_Kit.Descricao.Trim() == String.Empty)
            {
                Exception ex = new Exception("O campo Descrição é obrigatório");

                throw ex;
            }
        }

        #endregion KIT

        #region ESTOQUE
        public List<DtoEstoque> SelectEstoque()
        {
            try
            {
                List<DtoEstoque> lstEstoques = null;

                lstEstoques = objDal.SelectEstoque();

                return lstEstoques;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEstoque SelectEstoque(int p_IdEstoque)
        {
            try
            {
                DtoEstoque objEstoque = objDal.SelectEstoque(p_IdEstoque);

                return objEstoque;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditEstoque(DtoEstoque p_Estoque)
        {
            try
            {
                CheckFieldsEstoque(p_Estoque);

                // Remove espaços à esquerda e à direita
                p_Estoque.NomeModelo = p_Estoque.NomeModelo.Trim();

                objDal.EditEstoque(p_Estoque);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEstoque(DtoEstoque p_Estoque)
        {
            try
            {
                CheckFieldsEstoque(p_Estoque);

                // Remove espaços à esquerda e à direita
                p_Estoque.NomeModelo = p_Estoque.NomeModelo.Trim();

                objDal.InsertEstoque(p_Estoque);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEstoque(int p_IdEstoque)
        {
            try
            {
                objDal.DeleteEstoque(p_IdEstoque);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CheckFieldsEstoque(DtoEstoque p_Estoque)
        {
            // Validações de campo são obrigatórias na camada DLL
            // mesmo que já tenham sido feitas na camada PL
            if (p_Estoque.NomeModelo.Trim() == String.Empty)
            {
                Exception ex = new Exception("O campo Nome do Modelo é obrigatório");

                throw ex;
            }

        }
        #endregion ESTOQUE

        #region KIT PECA
        public List<DtoKitPeca> SelectKitPeca()
        {
            try
            {
                List<DtoKitPeca> lstKitPecas = null;

                lstKitPecas = objDal.SelectKitPeca();

                return lstKitPecas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoKitPeca> SelectKitPeca(int p_IdKitPeca)
        {
            try
            {
                List<DtoKitPeca> objKitPeca = objDal.SelectKitPeca(p_IdKitPeca);

                return objKitPeca;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EditKitPeca(DtoKitPeca p_KitPeca)
        {
            try
            {
                objDal.EditKitPeca(p_KitPeca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertKitPeca(DtoKitPeca p_KitPeca)
        {
            try
            {
                objDal.InsertKitPeca(p_KitPeca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteKitPeca(int p_IdKitPeca)
        {
            try
            {
                objDal.DeleteKitPeca(p_IdKitPeca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion KIT PECA

        #region ENTRADA E SAIDA
        public List<DtoEntradaSaida> SelectEntradaSaida()
        {
            try
            {
                List<DtoEntradaSaida> lstEntradaSaidas = null;
                

                lstEntradaSaidas = objDal.SelectEntradaSaida(null);

                return lstEntradaSaidas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoEntradaSaida> SelectEntradaSaidaPesquisa(string pesquisa)
        {
            try
            {
                List<DtoEntradaSaida> lstEntradaSaidas = null;


                lstEntradaSaidas = objDal.SelectEntradaSaida(pesquisa);

                return lstEntradaSaidas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DtoEntradaSaida SelectEntradaSaida(int p_IdEntradaSaida)
        {
            try
            {
                DtoEntradaSaida objEntradaSaida = objDal.SelectEntradaSaida(p_IdEntradaSaida);

                return objEntradaSaida;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void EditEntradaSaida(DtoEntradaSaida p_EntradaSaida)
        {
            try
            {
                CheckFieldsEntradaSaida(p_EntradaSaida);

                // Remove espaços à esquerda e à direita
                p_EntradaSaida.NumeroOrdem = p_EntradaSaida.NumeroOrdem.Trim();

                objDal.EditEntradaSaida(p_EntradaSaida);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaida(DtoEntradaSaida p_EntradaSaida)
        {
            try
            {
                CheckFieldsEntradaSaida(p_EntradaSaida);

                // Remove espaços à esquerda e à direita
                //p_EntradaSaida.NumeroOrdem = p_EntradaSaida.NumeroOrdem.Trim();

                objDal.InsertEntradaSaida(p_EntradaSaida);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaidaMax(DtoEntradaSaida p_EntradaSaida)
        {
            try
            {
                CheckFieldsEntradaSaida(p_EntradaSaida);

                // Remove espaços à esquerda e à direita
                //p_EntradaSaida.NumeroOrdem = p_EntradaSaida.NumeroOrdem.Trim();

                objDal.InsertEntradaSaida(p_EntradaSaida);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertEntradaSaidaKit(int IdKit, string NumeroOrdem)
        {
            try
            {
                NumeroOrdem = NumeroOrdem.Trim();
                objDal.InsertEntradaSaidaKit(IdKit, NumeroOrdem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteEntradaSaida(int p_IdEntradaSaida)
        {
            try
            {
                objDal.DeleteEntradaSaida(p_IdEntradaSaida);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<DtoEntradaSaida> SelectData(DateTime p_Data)
        {
            try
            {
                List<DtoEntradaSaida> objEntradaSaida  = objDal.SelectData(p_Data);

                return objEntradaSaida;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CheckFieldsEntradaSaida(DtoEntradaSaida p_EntradaSaida)
        {
            // Validações de campo são obrigatórias na camada DLL
            // mesmo que já tenham sido feitas na camada PL
            //if (p_EntradaSaida.NumeroOrdem.Trim() == String.Empty)
            //{
            //    Exception ex = new Exception("O campo Número da Ordem é obrigatório");

            //    throw ex;
            //}
        }
        #endregion ENTRADA E SAIDA

        #endregion METHODS
    }
}
