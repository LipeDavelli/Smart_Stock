﻿using prjBll;
using prjDto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCC_SmartStock
{
    public partial class frmVisualizarEstoque : Form
    {
        Bll objBll = new Bll();
        DtoEstoque Estoque;

        public frmVisualizarEstoque()
        {
            InitializeComponent();
        }

        public frmVisualizarEstoque(DtoEstoque estoque)
        {
            Estoque = estoque;

            InitializeComponent();
        }

        private void frmVisualizarEstoque_Load(object sender, EventArgs e)
        {
            dGV_estoque.DataSource = objBll.SelectPeca();
            dGV_estoque.Refresh();
        }

        private void dGV_Estoque_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            Form VoltarInicio = new frmTelaInicial();
            VoltarInicio.Show();
            this.Hide();
        }

        private void dGV_estoque_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPesquisa.Text))
            {
                //Codigo para atualizar o grid
                dGV_estoque.DataSource = objBll.SelectPecaPesquisa(txtPesquisa.Text);
                dGV_estoque.Refresh();
            }
            if (string.IsNullOrWhiteSpace(txtPesquisa.Text))
            {
                dGV_estoque.DataSource = objBll.SelectPeca();
                dGV_estoque.Refresh();
            }
        }

        private void btnVerEntradasESaidas_Click(object sender, EventArgs e)
        {
            new frmEntradasESaidas().Show();
            this.Hide();
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            
        }

        private void txtPesquisa_Click(object sender, EventArgs e)
        {
            txtPesquisa.Clear();
        }
    }
}
