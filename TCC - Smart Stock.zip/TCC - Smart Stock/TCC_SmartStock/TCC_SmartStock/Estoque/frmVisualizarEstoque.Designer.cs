﻿namespace TCC_SmartStock
{
    partial class frmVisualizarEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVisualizarEstoque));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pbReturn = new System.Windows.Forms.PictureBox();
            this.dGV_estoque = new System.Windows.Forms.DataGridView();
            this.idPecaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomePecaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantidadeEstoqueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.modeloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dtoPecaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnVerEntradasESaidas = new System.Windows.Forms.Button();
            this.txtPesquisa = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_estoque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtoPecaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pbReturn
            // 
            this.pbReturn.BackColor = System.Drawing.Color.Transparent;
            this.pbReturn.Image = ((System.Drawing.Image)(resources.GetObject("pbReturn.Image")));
            this.pbReturn.Location = new System.Drawing.Point(12, 12);
            this.pbReturn.Name = "pbReturn";
            this.pbReturn.Size = new System.Drawing.Size(71, 67);
            this.pbReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReturn.TabIndex = 1;
            this.pbReturn.TabStop = false;
            this.pbReturn.Click += new System.EventHandler(this.pbReturn_Click);
            // 
            // dGV_estoque
            // 
            this.dGV_estoque.AutoGenerateColumns = false;
            this.dGV_estoque.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_estoque.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dGV_estoque.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_estoque.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPecaDataGridViewTextBoxColumn,
            this.nomePecaDataGridViewTextBoxColumn,
            this.quantidadeEstoqueDataGridViewTextBoxColumn,
            this.modeloDataGridViewTextBoxColumn});
            this.dGV_estoque.DataSource = this.dtoPecaBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGV_estoque.DefaultCellStyle = dataGridViewCellStyle6;
            this.dGV_estoque.Location = new System.Drawing.Point(187, 308);
            this.dGV_estoque.Name = "dGV_estoque";
            this.dGV_estoque.ReadOnly = true;
            this.dGV_estoque.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGV_estoque.Size = new System.Drawing.Size(599, 427);
            this.dGV_estoque.TabIndex = 2;
            this.dGV_estoque.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_estoque_CellContentClick_1);
            // 
            // idPecaDataGridViewTextBoxColumn
            // 
            this.idPecaDataGridViewTextBoxColumn.DataPropertyName = "IdPeca";
            this.idPecaDataGridViewTextBoxColumn.HeaderText = "IdPeca";
            this.idPecaDataGridViewTextBoxColumn.Name = "idPecaDataGridViewTextBoxColumn";
            this.idPecaDataGridViewTextBoxColumn.ReadOnly = true;
            this.idPecaDataGridViewTextBoxColumn.Visible = false;
            // 
            // nomePecaDataGridViewTextBoxColumn
            // 
            this.nomePecaDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nomePecaDataGridViewTextBoxColumn.DataPropertyName = "NomePeca";
            this.nomePecaDataGridViewTextBoxColumn.HeaderText = "Peça";
            this.nomePecaDataGridViewTextBoxColumn.Name = "nomePecaDataGridViewTextBoxColumn";
            this.nomePecaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantidadeEstoqueDataGridViewTextBoxColumn
            // 
            this.quantidadeEstoqueDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.quantidadeEstoqueDataGridViewTextBoxColumn.DataPropertyName = "QuantidadeEstoque";
            this.quantidadeEstoqueDataGridViewTextBoxColumn.HeaderText = "Quantidade";
            this.quantidadeEstoqueDataGridViewTextBoxColumn.Name = "quantidadeEstoqueDataGridViewTextBoxColumn";
            this.quantidadeEstoqueDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // modeloDataGridViewTextBoxColumn
            // 
            this.modeloDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.modeloDataGridViewTextBoxColumn.DataPropertyName = "Modelo";
            this.modeloDataGridViewTextBoxColumn.HeaderText = "Modelo";
            this.modeloDataGridViewTextBoxColumn.Name = "modeloDataGridViewTextBoxColumn";
            this.modeloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dtoPecaBindingSource
            // 
            this.dtoPecaBindingSource.DataSource = typeof(prjDto.DtoPeca);
            // 
            // btnVerEntradasESaidas
            // 
            this.btnVerEntradasESaidas.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerEntradasESaidas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerEntradasESaidas.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEntradasESaidas.Location = new System.Drawing.Point(879, 647);
            this.btnVerEntradasESaidas.Name = "btnVerEntradasESaidas";
            this.btnVerEntradasESaidas.Size = new System.Drawing.Size(103, 88);
            this.btnVerEntradasESaidas.TabIndex = 9;
            this.btnVerEntradasESaidas.Text = "Entradas e Saídas";
            this.btnVerEntradasESaidas.UseVisualStyleBackColor = false;
            this.btnVerEntradasESaidas.Click += new System.EventHandler(this.btnVerEntradasESaidas_Click);
            // 
            // txtPesquisa
            // 
            this.txtPesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisa.Location = new System.Drawing.Point(367, 273);
            this.txtPesquisa.Name = "txtPesquisa";
            this.txtPesquisa.Size = new System.Drawing.Size(272, 29);
            this.txtPesquisa.TabIndex = 10;
            this.txtPesquisa.Text = "Pesquise uma peça";
            this.txtPesquisa.Click += new System.EventHandler(this.txtPesquisa_Click);
            this.txtPesquisa.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // frmVisualizarEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(994, 741);
            this.Controls.Add(this.txtPesquisa);
            this.Controls.Add(this.btnVerEntradasESaidas);
            this.Controls.Add(this.dGV_estoque);
            this.Controls.Add(this.pbReturn);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 726);
            this.Name = "frmVisualizarEstoque";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estoque";
            this.Load += new System.EventHandler(this.frmVisualizarEstoque_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_estoque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtoPecaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbReturn;
        private System.Windows.Forms.DataGridView dGV_estoque;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnVerEntradasESaidas;
        private System.Windows.Forms.TextBox txtPesquisa;
        private System.Windows.Forms.BindingSource dtoPecaBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPecaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomePecaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantidadeEstoqueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn modeloDataGridViewTextBoxColumn;
    }
}