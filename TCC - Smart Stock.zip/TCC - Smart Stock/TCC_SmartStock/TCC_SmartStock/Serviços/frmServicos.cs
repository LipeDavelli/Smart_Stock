﻿using prjBll;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjDto;

namespace TCC_SmartStock
{
    public partial class frmServicos : Form
    {
        private readonly Bll business;
        public frmServicos()
        {
            InitializeComponent();
            business = new Bll();
        }

        private void PuxaKits()
        {
            List<DtoKit> lstKit = business.SelectKit();
            cbKit.DataSource = lstKit;
            cbKit.DisplayMember = "NomeKit";
            cbKit.ValueMember = "IdKit";
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            Form Inicio = new frmTelaInicial();
            Inicio.Show();
            this.Hide();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            //Buscar todas as peças do kit
            //Inserir uma entrada e saida para cada peça
            //fazer a procedure
            //usar o while para inserir várias vezes


            try
            {

                List<DtoKitPeca> kitpeca = business.SelectKitPeca(int.Parse(cbKit.SelectedValue.ToString()));

                foreach (var item in kitpeca)
                {
                    business.InsertEntradaSaida(new DtoEntradaSaida() {
                        Kit = new DtoKit() { IdKit = item.Kit.IdKit},
                        Peca = new DtoPeca() { IdPeca = item.Peca.IdPeca},
                        NumeroOrdem = txtOrdem.Text,
                        Quantidade = item.Quantidade
                    });
                }

                MessageBox.Show("Serviço realizado com sucesso!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Todos os Campos devem ser preenchidos.", ex.Message);
            }
        }

        private void btnVerEstoque_Click(object sender, EventArgs e)
        {
            new frmEntradasESaidas().Show();
            this.Hide();
        }

        private void InicializarKits()
        {

            

        }

        private void frmServicos_Load(object sender, EventArgs e)
        {
            
        }

        private void cbKit_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cbKit_Click(object sender, EventArgs e)
        {
            PuxaKits();
        }
    }
}
