﻿namespace TCC_SmartStock
{
    partial class frmServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServicos));
            this.cbKit = new System.Windows.Forms.ComboBox();
            this.txtOrdem = new System.Windows.Forms.TextBox();
            this.btnVerEstoque = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.pbReturn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).BeginInit();
            this.SuspendLayout();
            // 
            // cbKit
            // 
            this.cbKit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbKit.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbKit.FormattingEnabled = true;
            this.cbKit.Location = new System.Drawing.Point(372, 477);
            this.cbKit.Name = "cbKit";
            this.cbKit.Size = new System.Drawing.Size(259, 37);
            this.cbKit.TabIndex = 0;
            this.cbKit.SelectedIndexChanged += new System.EventHandler(this.cbKit_SelectedIndexChanged);
            this.cbKit.Click += new System.EventHandler(this.cbKit_Click);
            // 
            // txtOrdem
            // 
            this.txtOrdem.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtOrdem.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrdem.Location = new System.Drawing.Point(372, 532);
            this.txtOrdem.Name = "txtOrdem";
            this.txtOrdem.Size = new System.Drawing.Size(259, 35);
            this.txtOrdem.TabIndex = 1;
            // 
            // btnVerEstoque
            // 
            this.btnVerEstoque.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerEstoque.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEstoque.Location = new System.Drawing.Point(516, 620);
            this.btnVerEstoque.Name = "btnVerEstoque";
            this.btnVerEstoque.Size = new System.Drawing.Size(96, 65);
            this.btnVerEstoque.TabIndex = 8;
            this.btnVerEstoque.Text = "Entradas e Saidas";
            this.btnVerEstoque.UseVisualStyleBackColor = false;
            this.btnVerEstoque.Click += new System.EventHandler(this.btnVerEstoque_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.SystemColors.Control;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Location = new System.Drawing.Point(382, 620);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(96, 65);
            this.btnSalvar.TabIndex = 7;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // pbReturn
            // 
            this.pbReturn.BackColor = System.Drawing.Color.Transparent;
            this.pbReturn.Image = ((System.Drawing.Image)(resources.GetObject("pbReturn.Image")));
            this.pbReturn.Location = new System.Drawing.Point(12, 12);
            this.pbReturn.Name = "pbReturn";
            this.pbReturn.Size = new System.Drawing.Size(71, 67);
            this.pbReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReturn.TabIndex = 9;
            this.pbReturn.TabStop = false;
            this.pbReturn.Click += new System.EventHandler(this.pbReturn_Click);
            // 
            // frmServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(994, 733);
            this.Controls.Add(this.pbReturn);
            this.Controls.Add(this.btnVerEstoque);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.txtOrdem);
            this.Controls.Add(this.cbKit);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 726);
            this.Name = "frmServicos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Serviços";
            this.Load += new System.EventHandler(this.frmServicos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbKit;
        private System.Windows.Forms.TextBox txtOrdem;
        private System.Windows.Forms.Button btnVerEstoque;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.PictureBox pbReturn;
    }
}