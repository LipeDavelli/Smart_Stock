﻿namespace TCC_SmartStock
{
    partial class frmEntradasESaidas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEntradasESaidas));
            this.dGVEntradasESaidas = new System.Windows.Forms.DataGridView();
            this.dtoEntradaSaidaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pbReturn = new System.Windows.Forms.PictureBox();
            this.btnVerEstoque = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtPesquisa = new System.Windows.Forms.TextBox();
            this.dTP_ES = new System.Windows.Forms.DateTimePicker();
            this.idEntradaSaidaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numeroOrdemDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Peca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantidadeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dGVEntradasESaidas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtoEntradaSaidaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).BeginInit();
            this.SuspendLayout();
            // 
            // dGVEntradasESaidas
            // 
            this.dGVEntradasESaidas.AutoGenerateColumns = false;
            this.dGVEntradasESaidas.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGVEntradasESaidas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dGVEntradasESaidas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVEntradasESaidas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idEntradaSaidaDataGridViewTextBoxColumn,
            this.numeroOrdemDataGridViewTextBoxColumn,
            this.kitDataGridViewTextBoxColumn,
            this.Peca,
            this.quantidadeDataGridViewTextBoxColumn,
            this.dataDataGridViewTextBoxColumn});
            this.dGVEntradasESaidas.DataSource = this.dtoEntradaSaidaBindingSource;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGVEntradasESaidas.DefaultCellStyle = dataGridViewCellStyle4;
            this.dGVEntradasESaidas.Location = new System.Drawing.Point(167, 321);
            this.dGVEntradasESaidas.Name = "dGVEntradasESaidas";
            this.dGVEntradasESaidas.ReadOnly = true;
            this.dGVEntradasESaidas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGVEntradasESaidas.Size = new System.Drawing.Size(613, 414);
            this.dGVEntradasESaidas.TabIndex = 0;
            this.dGVEntradasESaidas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGVEntradasESaidas_CellContentClick);
            // 
            // dtoEntradaSaidaBindingSource
            // 
            this.dtoEntradaSaidaBindingSource.DataSource = typeof(prjDto.DtoEntradaSaida);
            // 
            // pbReturn
            // 
            this.pbReturn.BackColor = System.Drawing.Color.Transparent;
            this.pbReturn.Image = ((System.Drawing.Image)(resources.GetObject("pbReturn.Image")));
            this.pbReturn.Location = new System.Drawing.Point(12, 12);
            this.pbReturn.Name = "pbReturn";
            this.pbReturn.Size = new System.Drawing.Size(71, 67);
            this.pbReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReturn.TabIndex = 10;
            this.pbReturn.TabStop = false;
            this.pbReturn.Click += new System.EventHandler(this.pbReturn_Click);
            // 
            // btnVerEstoque
            // 
            this.btnVerEstoque.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerEstoque.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEstoque.Location = new System.Drawing.Point(879, 647);
            this.btnVerEstoque.Name = "btnVerEstoque";
            this.btnVerEstoque.Size = new System.Drawing.Size(103, 88);
            this.btnVerEstoque.TabIndex = 11;
            this.btnVerEstoque.Text = "Estoque";
            this.btnVerEstoque.UseVisualStyleBackColor = false;
            this.btnVerEstoque.Click += new System.EventHandler(this.btnVerEstoque_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Peca";
            this.dataGridViewTextBoxColumn1.HeaderText = "Peca";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Peca";
            this.dataGridViewTextBoxColumn2.HeaderText = "Peca";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // txtPesquisa
            // 
            this.txtPesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesquisa.Location = new System.Drawing.Point(179, 286);
            this.txtPesquisa.Name = "txtPesquisa";
            this.txtPesquisa.Size = new System.Drawing.Size(272, 26);
            this.txtPesquisa.TabIndex = 13;
            this.txtPesquisa.Text = "Pesquise um numero da ordem";
            this.txtPesquisa.Click += new System.EventHandler(this.txtPesquisa_Click);
            this.txtPesquisa.TextChanged += new System.EventHandler(this.txtPesquisa_TextChanged);
            // 
            // dTP_ES
            // 
            this.dTP_ES.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTP_ES.Location = new System.Drawing.Point(457, 286);
            this.dTP_ES.Name = "dTP_ES";
            this.dTP_ES.Size = new System.Drawing.Size(323, 26);
            this.dTP_ES.TabIndex = 14;
            this.dTP_ES.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // idEntradaSaidaDataGridViewTextBoxColumn
            // 
            this.idEntradaSaidaDataGridViewTextBoxColumn.DataPropertyName = "IdEntradaSaida";
            this.idEntradaSaidaDataGridViewTextBoxColumn.HeaderText = "IdEntradaSaida";
            this.idEntradaSaidaDataGridViewTextBoxColumn.Name = "idEntradaSaidaDataGridViewTextBoxColumn";
            this.idEntradaSaidaDataGridViewTextBoxColumn.ReadOnly = true;
            this.idEntradaSaidaDataGridViewTextBoxColumn.Visible = false;
            // 
            // numeroOrdemDataGridViewTextBoxColumn
            // 
            this.numeroOrdemDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.numeroOrdemDataGridViewTextBoxColumn.DataPropertyName = "NumeroOrdem";
            this.numeroOrdemDataGridViewTextBoxColumn.HeaderText = "Numero da Ordem";
            this.numeroOrdemDataGridViewTextBoxColumn.Name = "numeroOrdemDataGridViewTextBoxColumn";
            this.numeroOrdemDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kitDataGridViewTextBoxColumn
            // 
            this.kitDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.kitDataGridViewTextBoxColumn.DataPropertyName = "Kit";
            this.kitDataGridViewTextBoxColumn.HeaderText = "Kit";
            this.kitDataGridViewTextBoxColumn.Name = "kitDataGridViewTextBoxColumn";
            this.kitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Peca
            // 
            this.Peca.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Peca.DataPropertyName = "Peca";
            this.Peca.HeaderText = "Peça";
            this.Peca.Name = "Peca";
            this.Peca.ReadOnly = true;
            // 
            // quantidadeDataGridViewTextBoxColumn
            // 
            this.quantidadeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.quantidadeDataGridViewTextBoxColumn.DataPropertyName = "Quantidade";
            this.quantidadeDataGridViewTextBoxColumn.HeaderText = "Quantidade";
            this.quantidadeDataGridViewTextBoxColumn.Name = "quantidadeDataGridViewTextBoxColumn";
            this.quantidadeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataDataGridViewTextBoxColumn
            // 
            this.dataDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataDataGridViewTextBoxColumn.DataPropertyName = "Data";
            this.dataDataGridViewTextBoxColumn.HeaderText = "Data";
            this.dataDataGridViewTextBoxColumn.Name = "dataDataGridViewTextBoxColumn";
            this.dataDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // frmEntradasESaidas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(994, 741);
            this.Controls.Add(this.dTP_ES);
            this.Controls.Add(this.txtPesquisa);
            this.Controls.Add(this.btnVerEstoque);
            this.Controls.Add(this.pbReturn);
            this.Controls.Add(this.dGVEntradasESaidas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 726);
            this.Name = "frmEntradasESaidas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Entradas e Saídas";
            this.Load += new System.EventHandler(this.frmEntradasESaidas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGVEntradasESaidas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtoEntradaSaidaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dGVEntradasESaidas;
        private System.Windows.Forms.PictureBox pbReturn;
        private System.Windows.Forms.BindingSource dtoEntradaSaidaBindingSource;
        private System.Windows.Forms.Button btnVerEstoque;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox txtPesquisa;
        private System.Windows.Forms.DateTimePicker dTP_ES;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEntradaSaidaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numeroOrdemDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Peca;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantidadeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataDataGridViewTextBoxColumn;
    }
}