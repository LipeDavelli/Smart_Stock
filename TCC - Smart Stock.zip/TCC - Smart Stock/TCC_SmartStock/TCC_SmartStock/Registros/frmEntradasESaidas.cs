﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjBll;

namespace TCC_SmartStock
{
    public partial class frmEntradasESaidas : Form
    {
        Bll objBll = new Bll();
        public frmEntradasESaidas()
        {
            InitializeComponent();
        }

        private void frmEntradasESaidas_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'smartStockDataSet.entrada_saida' table. You can move, or remove it, as needed.
            //this.entrada_saidaTableAdapter.Fill(this.smartStockDataSet.entrada_saida);

            dGVEntradasESaidas.DataSource = objBll.SelectEntradaSaida();
            dGVEntradasESaidas.Refresh();

            dTP_ES.CustomFormat = " ";
            dTP_ES.Format = DateTimePickerFormat.Custom;
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            new frmTelaInicial().Show();
            this.Hide();
        }

        private void btnVerEstoque_Click(object sender, EventArgs e)
        {
            new frmVisualizarEstoque().Show();
            this.Hide();
        }

        private void dGVEntradasESaidas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {

        }
   
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtPesquisa_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPesquisa.Text))
            {
                //Codigo para atualizar o grid
                dGVEntradasESaidas.DataSource = objBll.SelectEntradaSaidaPesquisa(txtPesquisa.Text);
                dGVEntradasESaidas.Refresh();
            }
            if (string.IsNullOrWhiteSpace(txtPesquisa.Text))
            {
                dGVEntradasESaidas.DataSource = objBll.SelectEntradaSaida();
                dGVEntradasESaidas.Refresh();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dTP_ES.CustomFormat = "dddd, d 'de' MMMM 'de' yyyy";

            List<prjDto.DtoEntradaSaida> list = objBll.SelectData(dTP_ES.Value.Date);
            dGVEntradasESaidas.DataSource = list;
            dGVEntradasESaidas.Refresh();
        }

        private void txtPesquisa_Click(object sender, EventArgs e)
        {
            txtPesquisa.Clear();
        }
    }
}
