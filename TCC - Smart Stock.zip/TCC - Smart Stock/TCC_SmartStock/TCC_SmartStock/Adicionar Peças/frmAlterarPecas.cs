﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using prjBll;
using prjDto;

namespace TCC_SmartStock
{
    public partial class frmAlterarPecas : Form
    {
        public Bll bll = new Bll();
        

        public frmAlterarPecas()
        {
            InitializeComponent();
        }

        private void PuxaPecas() 
        {
            List<DtoPeca> lstPeca = bll.SelectPeca();
            cbPecas.DataSource = lstPeca;
            cbPecas.DisplayMember = "NomePeca";
            cbPecas.ValueMember = "IdPeca";
        }


        private void cbQuantidade_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmAlterarPecas_Load(object sender, EventArgs e)
        {
                    for (int i = 1; i <= 1500; i++)
                    {                    
                        cbQuantidadeNova.Items.Add(i);
                    }
        }

        private void cbPecas_MouseClick(object sender, MouseEventArgs e)
        {
            PuxaPecas();
        }

        private void txtModelo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {

                DtoEntradaSaida es = new DtoEntradaSaida()
                {
                    Kit = new DtoKit(),
                    Quantidade = Convert.ToInt32(cbQuantidadeNova.Text),
                    Peca = new DtoPeca()
                    {
                        IdPeca = Convert.ToInt32(cbPecas.SelectedValue)
                    }
                };

                bll.InsertEntradaSaida(es);


                MessageBox.Show("Quantidade de peças alterada com sucesso!");

            }
            catch (Exception ex)
            {
                MessageBox.Show("Os campos devem ser preenchidos corretamente", ex.Message);
            }
        }

        private void btnVerEstoque_Click(object sender, EventArgs e)
        {
            new frmVisualizarEstoque().Show();
            this.Hide();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            new frmAddPeca().Show();
            this.Hide();
        }
    }
}
