﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjDto;
using prjBll;

namespace TCC_SmartStock
{
    public partial class frmAddPeca : Form
    {
        public DtoPeca Peca;
        private readonly Bll bll;

        public frmAddPeca()
        {
            InitializeComponent();
            bll = new Bll();
        }

        private void frmAddPeca_Load(object sender, EventArgs e)
        {
            for (int i = 1; i <= 1500; i++)
            {
                cbQuantidade.Items.Add(i);
            }
        
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            Form VoltarInicio = new frmTelaInicial();
            VoltarInicio.Show();
            this.Hide();
        }

        private void btnVerEstoque_Click(object sender, EventArgs e)
        {
            Form AbrirEstoque = new frmVisualizarEstoque();
            AbrirEstoque.Show();
            this.Hide();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(cbQuantidade.Text.ToString()) >= 0)
                {


                    Peca = new DtoPeca(txtNomePeca.Text, 0, txtModelo.Text);

                    bll.InsertPeca(Peca);

                    DtoEntradaSaida es = new DtoEntradaSaida()
                    {
                        Kit = new DtoKit(),
                        Quantidade = Convert.ToInt32(cbQuantidade.Text),
                        Peca = new DtoPeca()
                        {
                            IdPeca = Peca.IdPeca
                        }
                    };


                    bll.InsertEntradaSaida(es);

                    MessageBox.Show("Peça adicionada com sucesso!");
                    txtNomePeca.Clear();
                    txtModelo.Clear();
                    cbQuantidade.SelectedItem = null;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Todos os Campos devem ser preenchidos.", ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            new frmAlterarPecas().Show();
            this.Hide();
        }
    }
}
