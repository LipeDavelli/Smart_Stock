﻿namespace TCC_SmartStock
{
    partial class frmAddPeca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddPeca));
            this.txtNomePeca = new System.Windows.Forms.TextBox();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.cbQuantidade = new System.Windows.Forms.ComboBox();
            this.pbReturn = new System.Windows.Forms.PictureBox();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnVerEstoque = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNomePeca
            // 
            this.txtNomePeca.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtNomePeca.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNomePeca.Location = new System.Drawing.Point(389, 438);
            this.txtNomePeca.Name = "txtNomePeca";
            this.txtNomePeca.Size = new System.Drawing.Size(226, 35);
            this.txtNomePeca.TabIndex = 0;
            // 
            // txtModelo
            // 
            this.txtModelo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtModelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModelo.Location = new System.Drawing.Point(389, 509);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(226, 35);
            this.txtModelo.TabIndex = 1;
            // 
            // cbQuantidade
            // 
            this.cbQuantidade.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbQuantidade.FormattingEnabled = true;
            this.cbQuantidade.Location = new System.Drawing.Point(389, 581);
            this.cbQuantidade.Name = "cbQuantidade";
            this.cbQuantidade.Size = new System.Drawing.Size(226, 37);
            this.cbQuantidade.TabIndex = 2;
            this.cbQuantidade.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // pbReturn
            // 
            this.pbReturn.BackColor = System.Drawing.Color.Transparent;
            this.pbReturn.Image = ((System.Drawing.Image)(resources.GetObject("pbReturn.Image")));
            this.pbReturn.Location = new System.Drawing.Point(12, 12);
            this.pbReturn.Name = "pbReturn";
            this.pbReturn.Size = new System.Drawing.Size(71, 67);
            this.pbReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReturn.TabIndex = 4;
            this.pbReturn.TabStop = false;
            this.pbReturn.Click += new System.EventHandler(this.pbReturn_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.SystemColors.Control;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Location = new System.Drawing.Point(389, 651);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(87, 65);
            this.btnSalvar.TabIndex = 5;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // btnVerEstoque
            // 
            this.btnVerEstoque.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerEstoque.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEstoque.Location = new System.Drawing.Point(506, 651);
            this.btnVerEstoque.Name = "btnVerEstoque";
            this.btnVerEstoque.Size = new System.Drawing.Size(87, 65);
            this.btnVerEstoque.TabIndex = 6;
            this.btnVerEstoque.Text = "Abrir Estoque";
            this.btnVerEstoque.UseVisualStyleBackColor = false;
            this.btnVerEstoque.Click += new System.EventHandler(this.btnVerEstoque_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(895, 651);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 65);
            this.button1.TabIndex = 7;
            this.button1.Text = "Alterar Peças";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmAddPeca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(994, 741);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnVerEstoque);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.pbReturn);
            this.Controls.Add(this.cbQuantidade);
            this.Controls.Add(this.txtModelo);
            this.Controls.Add(this.txtNomePeca);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 766);
            this.Name = "frmAddPeca";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adicionar Peças";
            this.Load += new System.EventHandler(this.frmAddPeca_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNomePeca;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.ComboBox cbQuantidade;
        private System.Windows.Forms.PictureBox pbReturn;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnVerEstoque;
        private System.Windows.Forms.Button button1;
    }
}