﻿namespace TCC_SmartStock
{
    partial class frmAlterarPecas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAlterarPecas));
            this.cbPecas = new System.Windows.Forms.ComboBox();
            this.cbQuantidadeNova = new System.Windows.Forms.ComboBox();
            this.btnVerEstoque = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.pbReturn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).BeginInit();
            this.SuspendLayout();
            // 
            // cbPecas
            // 
            this.cbPecas.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbPecas.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPecas.FormattingEnabled = true;
            this.cbPecas.Location = new System.Drawing.Point(386, 485);
            this.cbPecas.Name = "cbPecas";
            this.cbPecas.Size = new System.Drawing.Size(226, 37);
            this.cbPecas.TabIndex = 3;
            this.cbPecas.SelectedIndexChanged += new System.EventHandler(this.cbQuantidade_SelectedIndexChanged);
            this.cbPecas.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cbPecas_MouseClick);
            // 
            // cbQuantidadeNova
            // 
            this.cbQuantidadeNova.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbQuantidadeNova.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbQuantidadeNova.FormattingEnabled = true;
            this.cbQuantidadeNova.Location = new System.Drawing.Point(386, 545);
            this.cbQuantidadeNova.Name = "cbQuantidadeNova";
            this.cbQuantidadeNova.Size = new System.Drawing.Size(226, 37);
            this.cbQuantidadeNova.TabIndex = 4;
            // 
            // btnVerEstoque
            // 
            this.btnVerEstoque.BackColor = System.Drawing.SystemColors.Control;
            this.btnVerEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerEstoque.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEstoque.Location = new System.Drawing.Point(502, 651);
            this.btnVerEstoque.Name = "btnVerEstoque";
            this.btnVerEstoque.Size = new System.Drawing.Size(87, 65);
            this.btnVerEstoque.TabIndex = 8;
            this.btnVerEstoque.Text = "Abrir Estoque";
            this.btnVerEstoque.UseVisualStyleBackColor = false;
            this.btnVerEstoque.Click += new System.EventHandler(this.btnVerEstoque_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.BackColor = System.Drawing.SystemColors.Control;
            this.btnSalvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalvar.Font = new System.Drawing.Font("Centaur", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalvar.Location = new System.Drawing.Point(386, 651);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(87, 65);
            this.btnSalvar.TabIndex = 7;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = false;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // pbReturn
            // 
            this.pbReturn.BackColor = System.Drawing.Color.Transparent;
            this.pbReturn.Image = ((System.Drawing.Image)(resources.GetObject("pbReturn.Image")));
            this.pbReturn.Location = new System.Drawing.Point(12, 12);
            this.pbReturn.Name = "pbReturn";
            this.pbReturn.Size = new System.Drawing.Size(71, 67);
            this.pbReturn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReturn.TabIndex = 11;
            this.pbReturn.TabStop = false;
            this.pbReturn.Click += new System.EventHandler(this.pbReturn_Click);
            // 
            // frmAlterarPecas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(994, 741);
            this.Controls.Add(this.pbReturn);
            this.Controls.Add(this.btnVerEstoque);
            this.Controls.Add(this.btnSalvar);
            this.Controls.Add(this.cbQuantidadeNova);
            this.Controls.Add(this.cbPecas);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 766);
            this.Name = "frmAlterarPecas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar Pecas";
            this.Load += new System.EventHandler(this.frmAlterarPecas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbReturn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbPecas;
        private System.Windows.Forms.ComboBox cbQuantidadeNova;
        private System.Windows.Forms.Button btnVerEstoque;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.PictureBox pbReturn;
    }
}