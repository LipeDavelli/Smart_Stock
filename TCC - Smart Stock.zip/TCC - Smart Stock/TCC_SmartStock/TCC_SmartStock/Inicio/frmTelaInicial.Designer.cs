﻿namespace TCC_SmartStock
{
    partial class frmTelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTelaInicial));
            this.pb_Estoque = new System.Windows.Forms.PictureBox();
            this.pb_Servicos = new System.Windows.Forms.PictureBox();
            this.pb_AddPecas = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Estoque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Servicos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_AddPecas)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_Estoque
            // 
            this.pb_Estoque.BackColor = System.Drawing.Color.Transparent;
            this.pb_Estoque.Location = new System.Drawing.Point(112, 538);
            this.pb_Estoque.Name = "pb_Estoque";
            this.pb_Estoque.Size = new System.Drawing.Size(186, 151);
            this.pb_Estoque.TabIndex = 0;
            this.pb_Estoque.TabStop = false;
            this.pb_Estoque.Click += new System.EventHandler(this.pb_Estoque_Click);
            // 
            // pb_Servicos
            // 
            this.pb_Servicos.BackColor = System.Drawing.Color.Transparent;
            this.pb_Servicos.Location = new System.Drawing.Point(403, 538);
            this.pb_Servicos.Name = "pb_Servicos";
            this.pb_Servicos.Size = new System.Drawing.Size(186, 151);
            this.pb_Servicos.TabIndex = 1;
            this.pb_Servicos.TabStop = false;
            this.pb_Servicos.Click += new System.EventHandler(this.pb_Servicos_Click);
            // 
            // pb_AddPecas
            // 
            this.pb_AddPecas.BackColor = System.Drawing.Color.Transparent;
            this.pb_AddPecas.Location = new System.Drawing.Point(699, 538);
            this.pb_AddPecas.Name = "pb_AddPecas";
            this.pb_AddPecas.Size = new System.Drawing.Size(186, 151);
            this.pb_AddPecas.TabIndex = 2;
            this.pb_AddPecas.TabStop = false;
            this.pb_AddPecas.Click += new System.EventHandler(this.pb_AddPecas_Click);
            // 
            // frmTelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(994, 747);
            this.Controls.Add(this.pb_AddPecas);
            this.Controls.Add(this.pb_Servicos);
            this.Controls.Add(this.pb_Estoque);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1010, 785);
            this.MinimumSize = new System.Drawing.Size(1010, 785);
            this.Name = "frmTelaInicial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            ((System.ComponentModel.ISupportInitialize)(this.pb_Estoque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Servicos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_AddPecas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_Estoque;
        private System.Windows.Forms.PictureBox pb_Servicos;
        private System.Windows.Forms.PictureBox pb_AddPecas;
    }
}

