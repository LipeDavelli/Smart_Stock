﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using prjDto;
using prjBll;

namespace TCC_SmartStock
{
    public partial class frmTelaInicial : Form
    {
        Bll objBll = new Bll();
     

        public frmTelaInicial()
        {
            InitializeComponent();
        }

        private void pb_Estoque_Click(object sender, EventArgs e)
        {
            Form Estoque = new frmVisualizarEstoque();
            Estoque.Show();
            this.Hide();
        }

        private void pb_AddPecas_Click(object sender, EventArgs e)
        {
            Form AddPeca = new frmAddPeca();
            AddPeca.Show();
            this.Hide();
        }

        private void pb_Servicos_Click(object sender, EventArgs e)
        {
            Form Servicos = new frmServicos();
            Servicos.Show();
            this.Hide();
        }
    }
}
