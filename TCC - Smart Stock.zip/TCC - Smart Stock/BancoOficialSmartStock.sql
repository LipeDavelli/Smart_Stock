USE master
GO
if EXISTS(select name from sys.databases where name = 'SmartStock') drop database SmartStock
GO

CREATE DATABASE SmartStock
GO
USE SmartStock 
GO
-------------------------------Tabela Pe�a-------------------------------
CREATE TABLE peca
(
	cod_peca INT IDENTITY PRIMARY KEY,
	nome_peca VARCHAR(100) NOT NULL,
	quantidade int not null default 0,
	modelo varchar(100)
)
GO
-------------------------------Tabela Kit-------------------------------
CREATE TABLE kit
(
    cod_kit INT IDENTITY(1,1) PRIMARY KEY,
    nome_kit VARCHAR(100) NOT NULL,
	descricao VARCHAR(1000)
)

insert into kit(nome_kit, descricao)
values('Basico','Kit contendo Pilha, Bateria e Antena')
GO
insert into kit(nome_kit, descricao)
values ('Smart','Kit regular')
GO
insert into kit(nome_kit, descricao)
values ('Premium','Kit mais completo')
GO
-------------------------------Tabela Kit-Pe�a-------------------------------
CREATE TABLE kit_peca
(
	cod_kit_peca INT PRIMARY KEY IDENTITY(1,1),
	cod_peca INT FOREIGN KEY REFERENCES peca(cod_peca),
	cod_kit INT FOREIGN KEY REFERENCES kit(cod_kit),
	quantidade INT
)


GO
-------------------------------Tabela Entrada-Saida-------------------------------
CREATE TABLE entrada_saida
(
	cod_entrada_saida INT IDENTITY PRIMARY KEY,
	numero_ordem VARCHAR(100),
	cod_peca INT FOREIGN KEY REFERENCES peca(cod_peca),
	cod_kit INT FOREIGN KEY REFERENCES kit(cod_kit) null,
	quantidade INT NOT NULL, --*
	data datetime default getdate()
)
GO
------INSERT
insert into peca(nome_peca, quantidade, modelo)
values('Pilha', 10, 'Duracell AA')
insert into peca(nome_peca, quantidade, modelo)
values('Bateria', 15, 'KT14')
insert into peca(nome_peca, quantidade, modelo)
values('Antena', 25, 'AX3000')
insert into peca(nome_peca, quantidade, modelo)
values('Chicote', 50, '194A')
insert into peca(nome_peca, quantidade, modelo)
values('Rolamento', 70, '88TFP')
insert into peca(nome_peca, quantidade, modelo)
values('Teclado', 35, 'Phillips A98')
GO

insert into kit_peca(cod_kit, cod_peca, quantidade)
values(1, 1, 2),(1, 2, 4), (1, 3, 1)

insert into kit_peca(cod_kit, cod_peca, quantidade)
values(2, 1, 2),(2, 2, 4), (2, 3, 1), (2, 4, 1)

insert into kit_peca(cod_kit, cod_peca, quantidade)
values(3, 1, 2),(3, 2, 4), (3, 3, 1), (3, 4, 1), (3, 5, 6), (3, 6, 1)
GO
-------------------------------PROCEDURES-------------------------------
------PE�A
CREATE PROCEDURE sp_insert_peca
	@p_nome_peca varchar(100),
	@p_quantidade int,
	@p_modelo varchar(100)
AS
BEGIN
	Insert peca(nome_peca, quantidade, modelo) 
	values (@p_nome_peca, @p_quantidade, @p_modelo)
	select max(cod_peca) from peca
END
GO

CREATE PROCEDURE sp_delete_peca
	@p_cod_peca int
AS
BEGIN
	delete peca where peca.cod_peca = @p_cod_peca
END
GO

CREATE PROCEDURE sp_update_peca
	@p_cod_peca int,
	@p_nome_peca varchar(100),
	@p_quantidade int,
	@p_modelo varchar
AS
BEGIN
	update peca set nome_peca = @p_nome_peca, quantidade = @p_quantidade, modelo = @p_modelo where peca.cod_peca = @p_cod_peca
END
GO

CREATE PROCEDURE sp_select_peca
	@p_search VARCHAR(50) = ''
AS
BEGIN
	Select * from peca
		WHERE nome_peca LIKE '%' + @p_search +'%';
END
GO

CREATE PROCEDURE sp_select_peca_by_cod
	@p_cod_peca int
AS
BEGIN
	Select * from peca p 
		where p.cod_peca = @p_cod_peca
END
GO
-----KIT
CREATE PROCEDURE sp_insert_kit
	@p_nome_kit varchar(100),
	@p_descricao varchar(1000)
AS
BEGIN
	Insert kit(nome_kit, descricao) output inserted.cod_kit values (@p_nome_kit, @p_descricao)
END
GO

CREATE PROCEDURE sp_delete_kit
	@p_cod_kit int
AS
BEGIN
	delete kit where kit.cod_kit = @p_cod_kit
END
GO
CREATE PROCEDURE sp_update_kit
	@p_cod_kit int,
	@p_nome_kit varchar(100),
	@p_descricao varchar(1000)
AS
BEGIN
	update kit set nome_kit = @p_nome_kit, descricao = @p_descricao where kit.cod_kit = @p_cod_kit
END
GO
CREATE PROCEDURE sp_select_kit
	@p_search varchar(50) = ''
AS
BEGIN
	Select * from kit where nome_kit like '%' + @p_search + '%'
END
GO
CREATE PROCEDURE sp_select_kit_by_cod
	@p_cod_kit int
AS
BEGIN
	Select * from vw_kit k where k.Codigo = @p_cod_kit
END
GO
---KIT-PE�A
CREATE PROCEDURE sp_insert_kit_peca
	@p_cod_peca int,
	@p_cod_kit int,
	@p_quantidade int
AS
BEGIN
	Insert into kit_peca(cod_peca, cod_kit, quantidade)
	values (@p_cod_peca, @p_cod_kit, @p_quantidade)
END
GO

CREATE PROCEDURE sp_delete_kit_peca
	@p_cod_kit_peca int
AS
BEGIN
	delete kit_peca where kit_peca.cod_kit_peca = @p_cod_kit_peca
END
GO

CREATE PROCEDURE sp_update_kit_peca
	@p_cod_kit_peca int,
	@p_cod_peca int,
	@p_cod_kit int,
	@p_quantidade int
AS
BEGIN
	update kit_peca set cod_peca = @p_cod_peca, cod_kit = @p_cod_kit, quantidade = @p_quantidade where kit_peca.cod_kit_peca = @p_cod_kit_peca
END
GO

CREATE PROCEDURE sp_select_kit_peca
	@p_search VARCHAR(50) = ''
AS
BEGIN
	SELECT	KP.cod_kit_peca
		,	P.cod_peca
		,	P.nome_peca
		,	P.quantidade AS quantidade_estoque
		,	K.cod_kit
		,	K.nome_kit
		,	K.descricao
		,	KP.quantidade AS quantidade_kit
		from kit_peca KP
		LEFT JOIN kit K
		ON K.cod_kit = KP.cod_kit
		LEFT JOIN peca P
		ON P.cod_peca = KP.cod_peca
	WHERE nome_kit LIKE '%' + @p_search +'%';
END
exec sp_select_kit_peca
GO

CREATE PROCEDURE sp_select_kit_peca_by_cod
	@p_cod_kit_peca int
AS
BEGIN
	SELECT	KP.cod_kit_peca
		,	P.cod_peca
		,	P.nome_peca
		,	P.quantidade AS quantidade_estoque
		,	K.cod_kit
		,	K.nome_kit
		,	K.descricao
		,	KP.quantidade AS quantidade_kit
		from kit_peca KP
		LEFT JOIN kit K
		ON K.cod_kit = KP.cod_kit
		LEFT JOIN peca P
		ON P.cod_peca = KP.cod_peca
	WHERE KP.cod_kit = @p_cod_kit_peca;
END
GO

--------ENTRADA-SAIDA
--*
CREATE PROCEDURE sp_insert_entrada_saida
	@p_numero_ordem varchar(100) = null,
	@p_quantidade INT,
	@p_cod_peca int,
	@p_cod_kit int null
AS

	if(@p_cod_kit = null or @p_cod_kit = '')
	begin
	Insert entrada_saida(numero_ordem, quantidade, cod_peca)
	values (@p_numero_ordem, @p_quantidade, @p_cod_peca)
	end
	else
BEGIN
	Insert entrada_saida(numero_ordem, quantidade, cod_peca , cod_kit)
	values (@p_numero_ordem, @p_quantidade, @p_cod_peca, @p_cod_kit)
END
GO

CREATE PROCEDURE sp_insert_entrada_saida_kit
	@p_numero_ordem varchar(100),
	@p_cod_kit int
	as
	begin
	Insert entrada_saida(numero_ordem, quantidade, cod_kit)
	values (@p_numero_ordem, 0, @p_cod_kit)
	end
	GO
--*
CREATE PROCEDURE sp_delete_entrada_saida
	@p_cod_entrada_saida int
AS
BEGIN
	delete entrada_saida where entrada_saida.cod_entrada_saida = @p_cod_entrada_saida
END
GO
--*
CREATE PROCEDURE sp_update_entrada_saida
	@p_cod_entrada_saida int,
	@p_numero_ordem varchar(100),
	@p_quantidade int
AS
BEGIN
	update entrada_saida set numero_ordem = @p_numero_ordem , quantidade = @p_quantidade where entrada_saida.cod_entrada_saida = @p_cod_entrada_saida
END
GO
--*
CREATE PROCEDURE sp_entrada_saida_data
	@p_data date
	AS
	BEGIN

	Select	ES.cod_entrada_saida
		,	Es.numero_ordem
		,	P.cod_peca
		,	P.nome_peca
		,	P.modelo
		,	K.cod_kit
		,	K.nome_kit
		,	Es.quantidade AS quantidade_peca
		,	ES.data
	from entrada_saida ES
	LEFT JOIN peca P
	ON P.cod_peca = Es.cod_peca
	LEFT JOIN kit K
	ON K.cod_kit = ES.cod_kit
		where cast (data as date) = @p_data
	END
	Go

CREATE PROCEDURE sp_select_entrada_saida
	@p_search VARCHAR(50) = ''
AS
BEGIN

	Select	ES.cod_entrada_saida
		,	Es.numero_ordem
		,	P.cod_peca
		,	P.nome_peca
		,	P.modelo
		,	K.cod_kit
		,	K.nome_kit
		,	Es.quantidade AS quantidade_peca
		,	ES.data
	from entrada_saida ES
	LEFT JOIN peca P
	ON P.cod_peca = Es.cod_peca
	LEFT JOIN kit K
	ON K.cod_kit = ES.cod_kit
	WHERE Es.numero_ordem LIKE '%' + @p_search +'%'
	OR ((Es.numero_ordem is null OR Es.numero_ordem = '') AND ('Entrada' like '%' + @p_search +'%' OR @p_search = ''))
	ORDER BY data DESC;
END

GO

CREATE PROCEDURE sp_entrada_saida_kit_by_cod
	@p_cod_entrada_saida int
AS
BEGIN
	Select	ES.cod_entrada_saida
		,	Es.numero_ordem
		,	P.cod_peca
		,	P.nome_peca
		,	K.cod_kit
		,	K.nome_kit
		,	Es.quantidade AS quantidade_peca
		,	ES.data
	from entrada_saida ES
	INNER JOIN peca P
	ON P.cod_peca = Es.cod_peca
	INNER JOIN kit K
	ON K.cod_kit = ES.cod_kit
	where es.cod_entrada_saida = @p_cod_entrada_saida
END
GO


-------------------------------Triggers-------------------------------
---*

CREATE TRIGGER tr_entrada_saida
ON entrada_saida
FOR INSERT
AS
BEGIN
	
	DECLARE @quantidade int, @cod_peca int, @numero_ordem VARCHAR(100)

	SELECT	@quantidade = quantidade
		,	@cod_peca = cod_peca
		,	@numero_ordem = numero_ordem
	FROM inserted

	IF(@numero_ordem = '' OR @numero_ordem IS NULL)
		BEGIN
			update peca
			set quantidade += @quantidade
			where cod_peca = @cod_peca
		END
	ELSE
		BEGIN
			--WHILE(@count < @quantidade)
			--BEGIN
				update peca
				set quantidade -= @quantidade
				where cod_peca = @cod_peca
			--END
		END
END
GO
SELECT * FROM entrada_saida
--------------------------------------------------------------
--CREATE TRIGGER tr_entrada_peca
--ON peca
--FOR
--INSERT
--AS
--BEGIN
	
--	SELECT * FROM entrada_saida

--	DECLARE @quantidade int, @cod_peca int


--	UPDATE peca
--	SET quantidade -= @quantidade
--	WHERE cod_peca = @cod_peca
--END
--GO






	--Select	ES.cod_entrada_saida
	--	,	Es.numero_ordem
	--	,	P.cod_peca
	--	,	P.nome_peca
	--	,	P.modelo
	--	,	K.cod_kit
	--	,	K.nome_kit
	--	,	Es.quantidade AS quantidade_peca
	--	,	ES.data
	--from entrada_saida ES
	--LEFT JOIN peca P
	--ON P.cod_peca = Es.cod_peca
	--LEFT JOIN kit K
	--ON K.cod_kit = ES.cod_kit
	--WHERE Es.numero_ordem LIKE '%' + '' +'%'
	--OR (Es.numero_ordem = NULL OR Es.numero_ordem = '') AND ('Entrada' like '%' + '' +'%' OR '' = ''))